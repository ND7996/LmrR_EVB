# Mechanism audit

Checked against the supplied FC mechanism drawing after removal of all arrow-overlaid assets.

| Modelled transformation | Mechanistic content represented in the PDB endpoints |
|---|---|
| 1.1 | pAF para-aniline N2 attacks enal carbonyl C10; C10=O16 becomes the tetrahedral N2-C10/C10-O16 ammonium-alkoxide. Indole is absent. |
| 1.2 | Two distinct water-derived bases are present. W1 accepts N-H29; W2 transfers H61 to O16, producing neutral carbinolamine plus the compensating W1 hydronium/W2 hydroxide pair. Indole is absent. |
| 1.3 | W1 supplies H29 to O16; C10-O16 is lost as water and N2=C10 iminium forms. W2 remains the counter-base. Indole is absent. |
| 2.1 | Indole is introduced only here. Indole C20 attacks enal beta carbon C12, giving the C12-C20 bond and the enamine/Wheland intermediate. |
| 2.2a | W2 accepts the indolium C20-H50 proton, restoring indole aromaticity. W1 remains a separate water. |
| 2.2b | W1 transfers H58 to enamine alpha carbon C11 while N2=C10 iminium character is restored. W2 retains H50. |

Mapping and composition checks:

- All nine Step 1 PDBs contain the same 57 atom serials and no IND residue.
- All nine Step 2 PDBs contain the same 76 atom serials and include IND.
- The common pAF/enal/water atoms retain their serials when moving from Step 1 to Step 2; the additional Step 2 serials belong to indole.
- W1 is always O27/H58/H59 and W2 is always O60/H61/H62.
- Every cluster has total formal charge zero.
- The full pAF backbone is present and neutrally capped as ACE-pAF-NME; the para-aniline reaction centre retains its original position relative to the reacting substrates.
- Capping adds only the ACE-pAF-NME backbone/cap atoms and repurposes the former methyl-cap hydrogens. Coordinates of the para-aniline reaction centre, enal, indole, and both waters remain unchanged.
- Atom-name fields follow the supplied PAF/IMI, IND, WAT, and PRD nomenclature; generated ACE/NME cap atoms use standard residue names.

Scope and QM caution:

- The requested six transformations end at 2.2b. The mechanism drawing's later Step 3 hydrolysis/product release is not modelled here.
- RS/PS files are chemically assigned endpoint models. TS files are starting geometries only; a true transition state must be confirmed by optimization, one imaginary frequency along the intended coordinate, and preferably IRC connections to the corresponding minima.
