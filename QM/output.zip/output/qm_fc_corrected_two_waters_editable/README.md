# Corrected editable FC mechanism package

This is the corrected production set.

- Step 1.1-1.3: 57 atoms, no indole, two explicit water-derived acid/base molecules.
- Step 2.1-2.2b: 76 atoms, indole present, two explicit water-derived acid/base molecules.
- Atom IDs/order are identical across RS/TS/PS within step 1 and within step 2.
- W1 = O27/H58/H59; W2 = O60/H61/H62.
- The full pAF backbone is restored and neutrally peptide-capped as ACE-pAF-NME. Source pAF atom names are retained; generated ACE/NME atoms use standard cap names.

Mechanistic proton assignments:

- 1.2: W1 accepts catalyst H29; W2 donates H61 to aldehyde O16.
- 1.3: W1 donates H29 to the leaving O16 water; W2 is the counter-hydroxide.
- 2.2a: W2 accepts indole C3 proton H50.
- 2.2b: the separate W1 donates H58 to enamine alpha carbon C11.

Folders contain application-compatible PDBs, the original arrow-free transparent PNGs, atom-complete PNGs, editable SVGs, and six arrow-free RS/TS/PS triptychs. PyMOL and ChimeraX loading scripts are in `scripts/`.

The package covers the requested sequence through 2.2b. The paper's later Step 3 hydrolysis/product-release reaction is not included. TS structures remain starting guesses requiring QM optimization, frequency analysis, and preferably IRC verification.
