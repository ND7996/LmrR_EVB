# ACE-pAF-NME geometry audit

Validated 18 PDB files: 57 atoms in each Step 1 structure and 76 atoms in each Step 2 structure.

The original para-aniline/enal/indole/water coordinates were preserved; only the restored pAF backbone and neutral ACE/NME caps were added.

## Cap geometry ranges

| Metric | Minimum | Maximum |
|---|---:|---:|
| CA-N | 1.460 A | 1.460 A |
| CA-C | 1.520 A | 1.520 A |
| C=O | 1.230 A | 1.230 A |
| N-ACE_C | 1.350 A | 1.351 A |
| ACE_C=O | 1.230 A | 1.230 A |
| ACE_C-CH3 | 1.510 A | 1.510 A |
| C-NME_N | 1.350 A | 1.350 A |
| NME_N-CH3 | 1.450 A | 1.450 A |
| ACE_C-N-CA | 119.982 degrees | 120.004 degrees |
| N-CA-C | 109.441 degrees | 109.441 degrees |
| CA-C-O | 120.001 degrees | 120.001 degrees |
| CA-C-NME_N | 120.008 degrees | 120.008 degrees |
| O-C-NME_N | 119.992 degrees | 119.992 degrees |
| C-NME_N-CH3 | 120.008 degrees | 120.008 degrees |
| ACE_O-C-N | 119.980 degrees | 119.990 degrees |
| ACE_N-C-CH3 | 119.988 degrees | 119.990 degrees |

All cap carbonyl/amide centres are planar and use standard starting bond lengths. The closest nonbonded cap contact found during construction was 1.780 A.

All reaction-coordinate distances for every RS/TS/PS file are listed in `geometry_distances.csv`. TS coordinates remain starting guesses requiring QM optimization and frequency/IRC confirmation.
