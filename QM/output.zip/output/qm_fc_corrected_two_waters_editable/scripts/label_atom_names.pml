# Run from the qm_fc_corrected_two_waters_editable directory in PyMOL.
@scripts/load_all_states.pml
label all, name
set label_color, black
set label_size, 14
