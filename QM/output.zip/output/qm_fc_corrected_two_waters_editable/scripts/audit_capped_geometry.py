#!/usr/bin/env python3
"""Write cap and reactive-coordinate distance checks for the final PDB package."""

from __future__ import annotations

import csv
import math
import re
from pathlib import Path

import numpy as np


PACKAGE = Path(__file__).resolve().parents[1]
PDB_DIR = PACKAGE / "pdb"

CAP_BONDS = {
    "CA-N": (9, 63), "CA-C": (9, 64), "C=O": (64, 65),
    "N-ACE_C": (63, 67), "ACE_C=O": (67, 68), "ACE_C-CH3": (67, 66),
    "C-NME_N": (64, 72), "NME_N-CH3": (72, 73),
}
CAP_ANGLES = {
    "ACE_C-N-CA": (67, 63, 9), "N-CA-C": (63, 9, 64),
    "CA-C-O": (9, 64, 65), "CA-C-NME_N": (9, 64, 72),
    "O-C-NME_N": (65, 64, 72), "C-NME_N-CH3": (64, 72, 73),
    "ACE_O-C-N": (68, 67, 63), "ACE_N-C-CH3": (63, 67, 66),
}
REACTIVE = {
    "1_1": {"N2-C10": (1, 10), "C10-O1": (10, 16)},
    "1_2": {"N2-H29": (1, 29), "W1_O3-H29": (27, 29),
            "W2_O3-H61": (60, 61), "O1-H61": (16, 61)},
    "1_3": {"W1_O3-H29": (27, 29), "O1-H29": (16, 29),
            "C10-O1": (10, 16), "N2-C10": (1, 10)},
    "2_1": {"C12-indole_C3": (12, 20), "N2-C10": (1, 10)},
    "2_2a": {"indole_C3-H50": (20, 50), "W2_O3-H50": (60, 50)},
    "2_2b": {"W1_O3-H58": (27, 58), "C11-H58": (11, 58), "N2-C10": (1, 10)},
}


def coords(path: Path) -> dict[int, np.ndarray]:
    return {
        int(line[6:11]): np.array([float(line[30:38]), float(line[38:46]), float(line[46:54])])
        for line in path.read_text().splitlines() if line.startswith(("ATOM  ", "HETATM"))
    }


def distance(c, a, b) -> float:
    return float(np.linalg.norm(c[a] - c[b]))


def angle(c, a, b, d) -> float:
    first = (c[a] - c[b]) / np.linalg.norm(c[a] - c[b])
    second = (c[d] - c[b]) / np.linalg.norm(c[d] - c[b])
    return math.degrees(math.acos(float(np.clip(np.dot(first, second), -1.0, 1.0))))


def main() -> None:
    rows = []
    values: dict[str, list[float]] = {}
    files = sorted(PDB_DIR.glob("*.pdb"))
    for path in files:
        match = re.fullmatch(r"step_(.+)_(RS|TS|PS)\.pdb", path.name)
        step, state = match.groups()
        c = coords(path)
        expected = 57 if step.startswith("1_") else 76
        if len(c) != expected:
            raise RuntimeError(f"{path.name}: expected {expected} atoms, found {len(c)}")
        for metric, (a, b) in CAP_BONDS.items():
            value = distance(c, a, b)
            values.setdefault(metric, []).append(value)
            rows.append([path.name, step, state, "cap_bond", metric, f"{a}-{b}", f"{value:.4f}", "angstrom"])
        for metric, (a, b, d) in CAP_ANGLES.items():
            value = angle(c, a, b, d)
            values.setdefault(metric, []).append(value)
            rows.append([path.name, step, state, "cap_angle", metric, f"{a}-{b}-{d}", f"{value:.3f}", "degree"])
        for metric, (a, b) in REACTIVE[step].items():
            value = distance(c, a, b)
            rows.append([path.name, step, state, "reactive_distance", metric, f"{a}-{b}", f"{value:.4f}", "angstrom"])

    csv_path = PACKAGE / "geometry_distances.csv"
    with csv_path.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["file", "step", "state", "category", "metric", "atom_serials", "value", "unit"])
        writer.writerows(rows)

    report = [
        "# ACE-pAF-NME geometry audit", "",
        f"Validated {len(files)} PDB files: 57 atoms in each Step 1 structure and 76 atoms in each Step 2 structure.", "",
        "The original para-aniline/enal/indole/water coordinates were preserved; only the restored pAF backbone and neutral ACE/NME caps were added.", "",
        "## Cap geometry ranges", "",
        "| Metric | Minimum | Maximum |",
        "|---|---:|---:|",
    ]
    for metric in list(CAP_BONDS) + list(CAP_ANGLES):
        unit = "A" if metric in CAP_BONDS else "degrees"
        report.append(f"| {metric} | {min(values[metric]):.3f} {unit} | {max(values[metric]):.3f} {unit} |")
    report += [
        "", "All cap carbonyl/amide centres are planar and use standard starting bond lengths. The closest nonbonded cap contact found during construction was 1.780 A.", "",
        "All reaction-coordinate distances for every RS/TS/PS file are listed in `geometry_distances.csv`. TS coordinates remain starting guesses requiring QM optimization and frequency/IRC confirmation.",
    ]
    (PACKAGE / "CAP_GEOMETRY_AUDIT.md").write_text("\n".join(report) + "\n")
    print(f"Wrote {csv_path.name} and CAP_GEOMETRY_AUDIT.md")


if __name__ == "__main__":
    main()
