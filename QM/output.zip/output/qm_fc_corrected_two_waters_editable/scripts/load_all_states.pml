# Run from the qm_fc_editable_assets directory.
reinitialize
set retain_order, 1
set connect_mode, 1
load pdb/step_1_1_RS.pdb, step_1_1_RS
load pdb/step_1_1_TS.pdb, step_1_1_TS
load pdb/step_1_1_PS.pdb, step_1_1_PS
group step_1_1, step_1_1_RS step_1_1_TS step_1_1_PS
load pdb/step_1_2_RS.pdb, step_1_2_RS
load pdb/step_1_2_TS.pdb, step_1_2_TS
load pdb/step_1_2_PS.pdb, step_1_2_PS
group step_1_2, step_1_2_RS step_1_2_TS step_1_2_PS
load pdb/step_1_3_RS.pdb, step_1_3_RS
load pdb/step_1_3_TS.pdb, step_1_3_TS
load pdb/step_1_3_PS.pdb, step_1_3_PS
group step_1_3, step_1_3_RS step_1_3_TS step_1_3_PS
load pdb/step_2_1_RS.pdb, step_2_1_RS
load pdb/step_2_1_TS.pdb, step_2_1_TS
load pdb/step_2_1_PS.pdb, step_2_1_PS
group step_2_1, step_2_1_RS step_2_1_TS step_2_1_PS
load pdb/step_2_2a_RS.pdb, step_2_2a_RS
load pdb/step_2_2a_TS.pdb, step_2_2a_TS
load pdb/step_2_2a_PS.pdb, step_2_2a_PS
group step_2_2a, step_2_2a_RS step_2_2a_TS step_2_2a_PS
load pdb/step_2_2b_RS.pdb, step_2_2b_RS
load pdb/step_2_2b_TS.pdb, step_2_2b_TS
load pdb/step_2_2b_PS.pdb, step_2_2b_PS
group step_2_2b, step_2_2b_RS step_2_2b_TS step_2_2b_PS
hide everything, all
show sticks, all
color atomic, all
set stick_radius, 0.16
set sphere_scale, 0.25
disable all
enable step_1_1_RS
zoom step_1_1_RS
